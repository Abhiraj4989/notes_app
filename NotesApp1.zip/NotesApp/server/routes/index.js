const express = require('express');
const router = express.Router();
const Note = require('../models/note-schema');
const User = require('../models/user-schema');
const basicAuth = require('express-basic-auth');


// // Middleware for Basic Auth
// //Update the Basic Auth middleware to use the actual username and password that you are sending in the request. Modify the users object accordingly.
// const basicAuthMiddleware = basicAuth({
//   users: { 'Abhiraj': 'Abhiraj' }, // Replace with your actual username and password
//   challenge: true,
//   unauthorizedResponse: 'Unauthorized',
// });

// // Apply Basic Auth Middleware to All Routes
// router.use(basicAuthMiddleware);





// Validate note data
const validateNote = (title, content) => {
  const errors = [];

  if (!title || title.trim().length === 0) {
    errors.push('Title is required');
  }

  if (!content || content.trim().length === 0) {
    errors.push('Content is required');
  }

  return errors;
};

// Create a Note
router.post('/notes', async (req, res) => {
  try {
    const { title, content, createdBy } = req.body;

    // Validate note data
    const validationErrors = validateNote(title, content);

    if (validationErrors.length > 0) {
      return res.status(400).send({ errors: validationErrors });
    }

    const note = new Note({ title, content, createdBy });
    await note.save();

    // Associate the note with the user
    const user = await User.findById(createdBy);

    if (!user) {
      return res.status(404).send({ error: 'User not found' });
    }

    user.notes.push(note._id);
    await user.save();

    res.status(201).send(note);
  } catch (error) {
    res.status(400).send(error);
  }
});

// Update a Note
router.patch('/notes/:id', async (req, res) => {
  const updates = Object.keys(req.body);
  const allowedUpdates = ['title', 'content'];
  const isValidOperation = updates.every((update) => allowedUpdates.includes(update));

  if (!isValidOperation) {
    return res.status(400).send({ error: 'Invalid updates!' });
  }

  try {
    const { title, content } = req.body;

    // Validate note data
    const validationErrors = validateNote(title, content);

    if (validationErrors.length > 0) {
      return res.status(400).send({ errors: validationErrors });
    }

    const note = await Note.findById(req.params.id);

    if (!note) {
      return res.status(404).send({ error: 'Note not found' });
    }

    updates.forEach((update) => (note[update] = req.body[update]));
    await note.save();

    res.send(note);
  } catch (error) {
    res.status(400).send(error);
  }
});

// Get All Notes
router.get('/notes', async (req, res) => {
  try {
    const notes = await Note.find();
    res.send(notes);
  } catch (error) {
    res.status(500).send(error);
  }
});

// Get a Single Note
router.get('/notes/:id', async (req, res) => {
  try {
    const note = await Note.findById(req.params.id);

    if (!note) {
      return res.status(404).send({ error: 'Note not found' });
    }

    res.send(note);
  } catch (error) {
    res.status(500).send(error);
  }
});

// Delete a Note
router.delete('/notes/:id', async (req, res) => {
  try {
    const note = await Note.findByIdAndDelete(req.params.id);

    if (!note) {
      return res.status(404).send({ error: 'Note not found' });
    }

    // Remove the note reference from the user's notes array
    const user = await User.findById(note.createdBy);

    if (!user) {
      return res.status(404).send({ error: 'User not found' });
    }

    user.notes = user.notes.filter((noteId) => noteId.toString() !== note._id.toString());
    await user.save();

    res.send(note);
  } catch (error) {
    res.status(500).send(error);
  }
});

// User Registration
router.post('/user', async (req, res) => {
  try {
    const { username, email, password } = req.body;
    const user = new User({ username, email, password });
    await user.save();
    res.status(201).send(user);
  } catch (error) {
    res.status(400).send(error);
  }
});

// User Login
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = await User.findOne({ username });

    if (!user) {
      return res.status(404).send({ error: 'User not found' });
    }

    const isMatch = await user.comparePassword(password);

    if (!isMatch) {
      return res.status(401).send({ error: 'Invalid password' });
    }

    res.send({ message: 'Login successful' });
  } catch (error) {
    res.status(500).send(error);
  }
});

module.exports = router;
